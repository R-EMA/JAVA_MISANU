package dan3;

public class Domine {
	
	private int a;
	private int b;
	
	Domine(int aa, int bb) {
		a = aa;
		b = bb;
	}
	
	public int getA() {
		return a;
	}
	
	public int getB() {
		return b;
	}
	
	public Domine okreni() {
		int temp = a;
		a = b;
		b = temp;
		return this;
	}
	
	public boolean proveri(Domine d) {
		return a == d.a && b == d.b || a == d.b && b == d.a;		
	}
	
	public String tekstualniOpis() {
		return "( " + a + " , " + b + " )";
	}
	
	
	
	
	

}
