package vozila;

public class TeretnoVozilo extends Vozilo {

	private double tezinaTereta;
	
	public TeretnoVozilo(double tezinaVozila, double tezinaTereta) {
		super(tezinaVozila);
		this.tezinaTereta = tezinaTereta;
		super.setVrstaVozila('T');
	}
	
	@Override
	public double ukupnaTezinaVozila() {
		// TODO Auto-generated method stub
		return super.getTezinaVozila() + this.tezinaTereta;
	}

	public String opisVozila() {
		return "Teretno vozilo težine " + super.getTezinaVozila() + 
				" tona, sa teretom težine " + this.tezinaTereta + " tona" +
				"\nUkupna bruto masa vozila je: " + this.ukupnaTezinaVozila() + " tona.";
	}
}
