package vozila;

public class PutnickoVozilo extends Vozilo {

	private int brojPutnika;
	private double tezinaPutnika;
	
	public PutnickoVozilo(double tezinaVozila, int brojPutnika, double tezinaPutnika) {
		super(tezinaVozila);
		this.brojPutnika = brojPutnika;
		this.tezinaPutnika = tezinaPutnika;
		super.setVrstaVozila('P');
	}

	@Override
	public double ukupnaTezinaVozila() {
		// TODO Auto-generated method stub
		return super.getTezinaVozila() + (this.brojPutnika * this.tezinaPutnika/1000);
	}

	@Override
	public String opisVozila() {
		// TODO Auto-generated method stub
		return "Putničko vozilo težine " + super.getTezinaVozila() + 
				" tona prevozi " + brojPutnika + " putnika. " + 
				"\nUkupna bruto masa vozila je: " + this.ukupnaTezinaVozila() + " tona.";
	}	

}
