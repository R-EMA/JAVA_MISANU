package vozila;

public abstract class Vozilo {
	
	private double tezinaVozila;
	private char vrstaVozila; // T - teretno, P - putnicko
	
	public Vozilo(double tezinaVozila) {
		this.tezinaVozila = tezinaVozila;
	}

	public double getTezinaVozila() {
		return tezinaVozila;
	}

	public void setTezinaVozila(double tezinaVozila) {
		this.tezinaVozila = tezinaVozila;
	}

	public char getVrstaVozila() {
		return vrstaVozila;
	}

	public void setVrstaVozila(char vrstaVozila) {
		this.vrstaVozila = vrstaVozila;
	}
	
	//ukupna tezina vozila
	public abstract double ukupnaTezinaVozila();
	
	//informacija da li vozilo može da prodje most;
	public void prohodnost(double nosivostMosta) {
		double masaVozila = this.ukupnaTezinaVozila();
		if ( masaVozila < nosivostMosta )
			System.out.println("\nVozilo može da prođe preko mosta!");
		else if (masaVozila > nosivostMosta)
			System.out.println("\nVozilo NE može da prođe preko mosta!");
		else
			System.out.println("\nVozilo jedva da može da prođe preko mosta. Prolazak se ne preporučuje!");
	}
	
	//opis vozila
	public abstract String opisVozila();
}
		
