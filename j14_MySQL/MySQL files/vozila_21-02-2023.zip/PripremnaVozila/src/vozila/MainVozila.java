package vozila;

import java.util.Scanner;

public class MainVozila {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in); // skener za unos podataka
		double most;	 // nosivost mosta	
		Vozilo objVozilo; // deklaracija neodređenog vozila

		// izbor tipa (vrste) vozila i definisanje njegovih osobina
		System.out.print("Unesite vrstu vozila (P - putničko; T - teretno): ");
		char vrstaVozila = sc.nextLine().charAt(0);
		System.out.print("Unesite težinu vozila izraženu u tonama: ");
		double tezinaVozila = sc.nextDouble();
		if(vrstaVozila == 'P' || vrstaVozila == 'p') {
			System.out.println("Izabrali ste putničko vozilo");
			System.out.print("Unesite broj putnika: ");
			int brojPutnika = sc.nextInt();
			System.out.print("Unesite prosečnu težinu putnika izraženo u kilogramima: ");
			double prosecnaTezinaPutnika = sc.nextDouble();
			objVozilo = new PutnickoVozilo(tezinaVozila, brojPutnika, prosecnaTezinaPutnika);
		}
		else if (vrstaVozila == 't' || vrstaVozila == 'T') {
			System.out.println("Izabrali ste teretno vozilo");
			System.out.print("Unesite tezinu tereta izraženo u tonama: ");
			double tezinaTereta = sc.nextDouble();
			objVozilo = new TeretnoVozilo(tezinaVozila, tezinaTereta);
		}
		else {
			System.out.println("Neodgovarajuća vrednost za tip vozila!");
			objVozilo = new PutnickoVozilo(tezinaVozila,52,75);
		}
		System.out.print("\nUnesite nosivost mosta: ");
		most = sc.nextDouble();
		System.out.println("\n" + objVozilo.opisVozila());
		objVozilo.prohodnost(most);
						
		sc.close();
	}

}
